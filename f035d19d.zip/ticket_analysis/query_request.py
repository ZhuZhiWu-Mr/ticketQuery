import time

from get_stations import *
import requests
import json  # 导入json模块
import urllib.parse
import urllib3

from urllib3.exceptions import InsecureRequestWarning

urllib3.disable_warnings(InsecureRequestWarning)

'''5-7 目的地 3  车次 6  出发地 8  出发时间 9  到达时间 10 历时 26 无坐 29 硬座
   24 软座 28 硬卧 33 动卧 23 软卧 21 高级软卧 30 二等座 31 一等座 32 商务座特等座
'''

data=[]          # 保存整理好的车次信息
type_data=[]     # 保存分类后的车次信息（如高铁，动车等）

today_car_list=[]    # 保存今天列车信息，已经处理是否有票
three_car_list=[]    # 保存三天列车信息，已经处理是否有票
five_car_list=[]     # 保存五天列车信息，已经处理是否有票

today_list=[]        # 保存今天列车信息，未处理是否有票
three_list=[]        # 保存三天列车信息，未处理是否有票
five_list=[]         # 保存五天列车信息，未处理是否有票

station_name_list=[]     #保存起售车站名称列表
station_time_list=[]     #保存起售车站对应时间列表


def query(date,get_from,from_station,get_to,to_station):
    data.clear()        # 清空数据
    type_data.clear()
    # 查询请求地址
    url = 'https://kyfw.12306.cn/otn/leftTicket/query?leftTicketDTO.train_date={}&leftTicketDTO.from_station={}&leftTicketDTO.to_station={}&purpose_codes=ADULT'.format(date, from_station, to_station)
    header={
        "Accept": "* / *",
        "Accept - Encoding": "gzip, deflate, br",
        "Accept - Language": "zh - CN, zh;q = 0.8, zh - TW;q = 0.7, zh - HK;q = 0.5, en - US;q = 0.3, en;q = 0.2",
        "Cache - Control": "no - cache",
        "Connection": "keep - alive",
        "Host": "kyfw.12306.cn",
        "If - Modified - Since": "0",
        "User - Agent": "Mozilla / 5.0(Windows NT 10.0;Win64;x64;rv: 79.0) Gecko / 20100101 Firefox / 79.0",
        "X - Requested - With": "XMLHttpRequest"
    }
    cookie={
        "_jc_save_fromDate": date,
        "_jc_save_fromStation": urllib.parse.quote(get_from)+','+from_station,
        "_jc_save_toDate": time.strftime("%Y-%m-%d", time.localtime(int(time.time()))),
        "_jc_save_toStation": urllib.parse.quote(get_to)+','+to_station,
        "_jc_save_wfdc_flag": "dc",
        "_uab_collina": "159732157974892376877548",
        "BIGipServerotn": "1223688714.38945.0000",
        "BIGipServerpool_passport": "334299658.50215.0000",
        "RAIL_DEVICEID": "bg9kzYAAmWLKvkGjSXloVeUS13AMawZZ0VCofAFsFII7 - Ct2O5TnBIDzh58wGCX0auhIk38UI87ychnhAYOfQk21lGdigJJc5ipe76mTYWBBr10CQzSMsZPSjJ9HoUcQ9Jd4 - pmJTaiE9Yr2QwYS3v1iLIW8tvBI",
        "RAIL_EXPIRATION": "1597661155102",
        "route": "9036359bb8a8a461c164a04f8f50b252"
    }
    print(url)
    print(cookie)
    response=requests.get(url,headers=header,verify=False)           # 发送查询请求
    print('正确1')
    if response.text.startswith(u'\ufeff'):
        response.text = response.text.encode('utf8')[3:].decode('utf8')
    response.encoding = 'utf-8'
    #print(response.text)
    #print(response.headers)
    print(response.url)
    print('正确2')

    result = json.loads(response.text)
    print('正确3')
    result=result['data']['result']
    print('正确4')
    # 判断车站文件是否存在
    if is_stations('stations.text') :
        stations=eval(read('stations.text'))     # 读取所有车站并转换为字典类型
        if len(stations)!=0:                     # 判断返回数据是否为空
            for i in result:
                tmp_list=i.split('|')            # 分割数据并添加到列表中
                print(tmp_list)
                #因为查询结果中出发站和到达站为站名的缩写字母，所以需要在车站库中找到对应的车站名称
                from_station=list(stations.keys())[list(stations.values()).index(tmp_list[6])]
                to_station=list(stations.keys())[list(stations.values()).index(tmp_list[7])]
                #创建座位数组，由于返回的作为数据中含有空值，所以将空改成“--”这样好识别
                seat=[tmp_list[3],from_station,to_station,tmp_list[8],tmp_list[9],tmp_list[10],
                      tmp_list[32],tmp_list[31],tmp_list[30],tmp_list[21],tmp_list[23],
                      tmp_list[33],tmp_list[28],tmp_list[24],tmp_list[29],tmp_list[26]]
                print(seat)
                newSeat=[]
                #循环将座位信息中的空值改成“--”
                for s in seat:
                    if s=="":
                        s="--"
                    else:
                        s=s
                    newSeat.append(s)  # 保存新的座位信息
                data.append(newSeat)
                print(newSeat)
            return data    # 返回整理好的车次信息


#获取高铁信息的方法
def g_vehicle():
    if len(data)!=0:
        for g in data:                   #循环所有火车数据
            i = g[0].startswith('G')     #判断车次首字母是不是高铁
            if i:                        #如果是，将该信息添加到高铁数据中
                type_data.append(g)
#移除高铁信息的方法
def r_g_vehicle():
    if len(data)!=0 and len(type_data)!=0:
        for g in data:
            i=g[0].startswith('G')
            if i:
                type_data.remove(g)

#获取动车信息的方法
def d_vehicle():
    if len(data)!=0:
        for d in data:                   #循环所有火车数据
            i = d[0].startswith('D')     #判断车次首字母是不是动车
            if i:                        #如果是，将该信息添加到动车数据中
                type_data.append(d)
#移除动车信息的方法
def r_d_vehicle():
    if len(data)!=0 and len(type_data)!=0:
        for d in data:
            i=d[0].startswith('D')
            if i:
                type_data.remove(d)

#获取直达车信息的方法
def z_vehicle():
    if len(data)!=0:
        for z in data:                   #循环所有火车数据
            i = z[0].startswith('Z')     #判断车次首字母是不是直达车
            if i:                        #如果是，将该信息添加到直达车数据中
                type_data.append(z)
#移除直达车信息的方法
def r_z_vehicle():
    if len(data)!=0 and len(type_data)!=0:
        for z in data:
            i=z[0].startswith('Z')
            if i:
                type_data.remove(z)

#获取特快车信息的方法
def t_vehicle():
    if len(data)!=0:
        for t in data:                   #循环所有火车数据
            i = t[0].startswith('T')     #判断车次首字母是不是特快车
            if i:                        #如果是，将该信息添加到特快车数据中
                type_data.append(t)
#移除特快车信息的方法
def r_t_vehicle():
    if len(data)!=0 and len(type_data)!=0:
        for t in data:
            i=t[0].startswith('T')
            if i:
                type_data.remove(t)

#获取快速车信息的方法
def k_vehicle():
    if len(data)!=0:
        for k in data:                   #循环所有火车数据
            i = k[0].startswith('K')     #判断车次首字母是不是快速车
            if i:                        #如果是，将该信息添加到快速车数据中
                type_data.append(k)
#移除动车信息的方法
def r_k_vehicle():
    if len(data)!=0 and len(type_data)!=0:
        for k in data:
            i=k[0].startswith('K')
            if i:
                type_data.remove(k)



#判断高级软卧、软卧、硬卧是否有票
def is_ticket(tmp_list,from_station,to_station):
    # 判断高级软卧、软卧、硬卧任何一个有票的话，就说明该趟车有卧铺票
    if tmp_list[21]=='有' or tmp_list[23]=='有' or tmp_list[28]=='有':
        tmp_tem='有'
    else:
        # 判断高级软卧、软卧、硬卧对应的如果是数字说明也有票，其他为无票
        if tmp_list[21].isdigit() or tmp_list[23].isdigit() or tmp_list[28].isdigit():
            tmp_tem='有'
        else:
            tmp_tem='无'
    #创建新的座位列表，显示某趟车是否有卧铺票
    new_seat=[tmp_list[3],from_station,to_station,tmp_list[8],tmp_list[9],tmp_list[10],tmp_tem]
    return new_seat

#查询卧铺售票分析数据
def query_ticketing_analysis(date,from_station,to_station,which_day):
    #查询请求地址
    url = 'https://kyfw.12306.cn/otn/leftTicket/query?leftTicketDTO.train_date={}&leftTicketDTO.from_station={}' \
          '&leftTicketDTO.to_station={}&purpose_codes=ADULT'.format(date,from_station,to_station)
    #发送查询请求
    response=requests.get(url)
    # 将json数据转换为字典类型，通过键值对取数据
    result=response.json()
    result=result['data']['result']
    # 判断车站文件是否存在
    if is_stations('stations.text') :
        stations=eval(read('stations.text'))     # 读取所有车站并转换为字典类型
        if len(stations)!=0:                     # 判断返回数据是否为空
            for i in result:
                # 分割数据并添加到列表中
                tmp_list=i.split('|')
                #print(tmp_list)
                #因为查询结果中出发站和到达站为站名的缩写字母，所以需要在车站库中找到对应的车站名称
                from_station=list(stations.keys())[list(stations.values()).index(tmp_list[6])]
                to_station=list(stations.keys())[list(stations.values()).index(tmp_list[7])]
                #创建座位数组，其中包含高级软卧、软卧、硬卧
                seat=[tmp_list[3],from_station,to_station,tmp_list[8],tmp_list[9],tmp_list[10],
                      tmp_list[21],tmp_list[23],tmp_list[28]]
                #print(seat)

                #判断今天的车次信息
                if which_day==1:
                    #将高铁、动、C开头的车次排除
                    if seat[0].startswith('G') is False and seat[0].startswith('D') is False and seat[0].startswith('C') is False:
                        #将高级软卧、软卧、硬卧未处理信息添加至列表中
                        today_list.append(seat)
                        #判断某车次是否有票
                        new_seat=is_ticket(tmp_list,from_station,to_station)
                        #将判断后的车次信息添加至对应的列表中
                        today_car_list.append(new_seat)
                #判断三天的车次信息
                if which_day==3:
                    if seat[0].startswith('G') is False and seat[0].startswith('D') is False and seat[0].startswith('C') is False:
                        three_list.append(seat)
                        new_seat=is_ticket(tmp_list,from_station,to_station)
                        three_car_list.append(new_seat)
                #判断五天的车次信息
                if which_day==5:
                    if seat[0].startswith('G') is False and seat[0].startswith('D') is False and seat[0].startswith('C') is False:
                        five_list.append(seat)
                        new_seat=is_ticket(tmp_list,from_station,to_station)
                        five_car_list.append(new_seat)

#查询车票起售时间
def query_time(station):
    station_name_list.clear()
    station_time_list.clear()
    #读取所有车站并转换为字典类型
    stations=eval(read('time.text'))
    url='https://www.12306.cn/index/otn/index12306/queryScSname'
    #表单参数，station参数为需要搜索车站的英文缩写
    form_data={"station_telecode":station}
    response=requests.post(url,data=form_data,verify=True)  # 请求并进行验证
    response.encoding='utf-8'                        # 对请求所返回的数据进行编码

    json_data=json.loads(response.text)              # 解析json数据
    data=json_data.get('data')                       # 获取json中可用数据，也就是查询车站所对应的站名

    for i in data:                                   # 遍历查询车站所对应的所有站名
        if i in stations:                            # 在站名时间文件中，判断是否存在该站名
            station_name_list.append(i)              # 有该站名就将站名添加至列表中
    for name in station_name_list:                   # 遍历筛选后的站名
        time=stations.get(name)                      # 通过站名获取对应的时间
        station_time_list.append(time)               # 将时间保存至列表
    return station_name_list,station_time_list